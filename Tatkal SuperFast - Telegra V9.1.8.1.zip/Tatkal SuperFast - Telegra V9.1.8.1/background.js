// background.js
let incognitoWindowIds = new Set();
let irctcWinId = null;
let irctcTabId = null;
let isSimulating = false;


chrome.storage.sync.set({
  CANVAS_SPOOFED: false,
});


// ─────────────────────────────────────────────────────────────────────────────
// Debugger orchestration: capture loginCaptcha & webtoken bodies
// ─────────────────────────────────────────────────────────────────────────────

let currentDebugTab = null;
const pendingRequests = new Map();  // requestId → url

// 1) Call this once, immediately after your declarations:
initializeDebuggerListener();

// 2) Register a single onEvent listener
function initializeDebuggerListener() {
  chrome.debugger.onEvent.addListener((debuggeeId, method, params) => {
    if (debuggeeId.tabId !== currentDebugTab) return;

    // A) Capture any loginCaptcha or webtoken requests as soon as headers arrive
    if (method === "Network.responseReceived") {
      const { requestId, response } = params;
      const url = response.url;
      if (/loginCaptcha/.test(url) || /authprovider\/webtoken/.test(url)) {
        pendingRequests.set(requestId, url);
      }
    }

    // B) Once Chrome finishes downloading the body, fetch it
    else if (method === "Network.loadingFinished") {
      const { requestId } = params;
      const url = pendingRequests.get(requestId);
      if (!url) return;
      pendingRequests.delete(requestId);

      chrome.debugger.sendCommand(
        { tabId: debuggeeId.tabId },
        "Network.getResponseBody",
        { requestId },
        result => {
          if (chrome.runtime.lastError) {
            console.error("getResponseBody error:", chrome.runtime.lastError.message);
            return;
          }
          if (!result?.body) {
            console.warn(`Empty body for ${url}`);
            return;
          }

          let data;
          try {
            data = JSON.parse(result.body);
          } catch (e) {
            console.error(`JSON parse error for ${url}:`, e, result.body);
            return;
          }
          if (/loginCaptcha/.test(url)) {
            // greq endpoint
            const greq = data.status || "";
            chrome.storage.local.set({
              greq,
              captchaResponse: result.body
            }, () => console.log("✔️ Stored greq & captchaResponse:", greq));
          } else {
            // webtoken endpoint
            chrome.storage.local.set({ signInResponse: result.body }, () =>
              console.log("✔️ Stored signInResponse")
            );

            if (data.token_type?.toLowerCase() === "bearer" && data.access_token) {
              chrome.storage.local.set({ accessToken: data.access_token }, () =>
                console.log("✔️ Stored accessToken:", data.access_token)
              );
            } else {
              console.warn("Unexpected webtoken payload or missing access_token:", data);
            }
          }
        }
      );
    }
  });
}

// 3) Attach the debugger & enable Network for a given tab
function setupDebuggerForTab(tabId) {
  currentDebugTab = tabId;
  chrome.debugger.attach({ tabId }, "1.3", () => {
    if (chrome.runtime.lastError) {
      console.error("Debugger attach error:", chrome.runtime.lastError.message);
      return;
    }
    chrome.debugger.sendCommand({ tabId }, "Network.enable", {}, err => {
      if (err || chrome.runtime.lastError) {
        //console.error("Network.enable error:", (err || chrome.runtime.lastError.message));
        return;
      }
      console.log(`🔍 Debugger + Network.enabled on tab#${tabId}`);
    });
  });
}

// 4) Cleanly detach when you’re done
function cleanupDebugger(tabId) {
  try {
    chrome.debugger.detach({ tabId }, () => {
      if (chrome.runtime.lastError) {
        console.warn("Debugger detach error:", chrome.runtime.lastError.message);
      } else {
        console.log(`🛑 Debugger detached from tab#${tabId}`);
      }
    });
  } catch (e) {
    console.error("Error in cleanupDebugger:", e);
  }
}



// ─────────────────────────────────────────────────────────────────────────────
// 0) Device‑fingerprint helpers: random User‑Agent & random viewport
// ─────────────────────────────────────────────────────────────────────────────
const USER_AGENTS = [
  'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (iPad; CPU OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (iPad; CPU OS 13_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-N986B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 10; SM-T865) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 11_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0',
  'Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0',
  'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edg/108.0.1462.76 Safari/537.36',
  'Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; Nexus 5 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
  'Mozilla/5.0 (Linux; arm; Android 9; SM-A105F Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; U; Android 8.1.0; en-us; Lenovo TB-8504F Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/70.0.3538.80 Safari/537.36',
  'Mozilla/5.0 (Linux; Android 7.0; SM-G930K Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36'
];

function getRandomUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function getRandomDimensions() {
  const presets = [
    { width: 375, height: 667 },{ width: 414, height: 896 },{ width: 390, height: 844 },
    { width: 428, height: 926 },{ width: 768, height: 1024 },{ width: 834, height: 1194 },
    { width: 1024, height: 1366 },{ width: 360, height: 760 },{ width: 393, height: 851 },
    { width: 360, height: 640 },{ width: 412, height: 915 },{ width: 412, height: 869 },
    { width: 1440, height: 900 },{ width: 1536, height: 864 },{ width: 1920, height: 1080 },
    { width: 2560, height: 1440 },{ width: 3840, height: 2160 },{ width: 1280, height: 800 },
    { width: 1366, height: 768 },{ width: 1600, height: 900 }
  ];
  return presets[Math.floor(Math.random() * presets.length)];
}

function setRandomUA(ua) {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [10],
    addRules: [{
      id: 10,
      priority: 2,
      action: { type: "modifyHeaders", requestHeaders: [{ header: "User-Agent", operation: "set", value: ua }] },
      condition: { urlFilter: "<all_urls>", resourceTypes: ["main_frame","xmlhttprequest","sub_frame","other"] }
    }]
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// 1) On installed/updated: set up dynamic header rules (ids 1–7)
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1,2,3,4,5,6,7],
    addRules: [
      // Rule 1
      {
        id: 1, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Referer", operation: "set", value: "https://www.wps.irctc.co.in/" }
        ]},
        condition: { urlFilter: "https://www.irctcipay.com/pgui/jsp/surchargelocale?request_localeA=&defaultLanguageA=", resourceTypes: ["main_frame","xmlhttprequest"] }
      },
      // Rule 2
      {
        id: 2, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Origin", operation: "set", value: "https://www.irctcipay.com" },
          { header: "Referer", operation: "set", value: "https://www.irctcipay.com/pgui/jsp/surchargePaymentPage.jsp" }
        ]},
        condition: { urlFilter: "https://www.irctcipay.com/*", resourceTypes: ["main_frame","xmlhttprequest"] }
      },
      // Rule 3
      {
        id: 3,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Accept",           operation: "set", value: "application/json, text/plain, */*" },
            { header: "Accept-Encoding",  operation: "set", value: "gzip, deflate, br" },
            { header: "Origin",           operation: "set", value: "https://www.irctc.co.in" },
            { header: "Referer",          operation: "set", value: "https://www.irctc.co.in/nget/train-search" },
            { header: "bmirak",           operation: "set", value: "webbm" },
            { header: "Dnt",              operation: "set", value: "1" },
            { header: "Priority",         operation: "set", value: 'u="1","i"' },
            { header: "Sec-Fetch-Site",   operation: "set", value: "same-origin" },
            { header: "Connection",       operation: "set", value: "keep-alive" },
            { header: "Sec-Fetch-Mode",   operation: "set", value: "cors" },
            { header: "Sec-Fetch-Dest",   operation: "set", value: "empty" },
            { header: "Sec-Ch-Ua-Mobile", operation: "set", value: "?1" },
            { header: "Sec-Ch-Ua-Platform", operation: "set", value: `"Android"` }
          ]
        }, 
        condition: {
          urlFilter: "|https://www.irctc.co.in/eticketing/*",
          resourceTypes: ["main_frame","xmlhttprequest","sub_frame","other"]
        }
      },
      // Rule 4
      {
        id: 4, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Origin", operation: "set", value: "https://secure.paytmpayments.com" },
          { header: "Referer", operation: "set", value: "https://secure.paytmpayments.com/" }
        ]},
        condition: { urlFilter: "https://secure.paytmpayments.com/theia/api/v1/processTransaction", resourceTypes: ["main_frame","xmlhttprequest"] }
      },
      // Rule 5
      {
        id: 5, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Accept", operation: "set", value: "application/json, text/plain, */*" },
          { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
          { header: "Origin", operation: "set", value: "https://www.irctc.co.in" },
          { header: "Referer", operation: "set", value: "https://www.irctc.co.in/nget/train-search" }
        ]},
        condition: { urlFilter: "https://www.wps.irctc.co.in/*", resourceTypes: ["main_frame","xmlhttprequest"] }
      },
      // Rule 6
      {
        id: 6, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Accept", operation: "set", value: "application/json, text/plain, */*" },
          { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
          { header: "Origin", operation: "set", value: "https://www.irctc.co.in" },
          { header: "Referer", operation: "set", value: "https://www.irctc.co.in/nget/train-search" },
          { header: "bmirak", operation: "set", value: "webbm" }
        ]},
        condition: { urlFilter: "|https://www.irctc.co.in/authprovider/webtoken*", resourceTypes: ["xmlhttprequest"] }
      },
      // Rule 7
      {
        id: 7, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Origin", operation: "set", value: "https://askdisha.irctc.co.in" },
          { header: "Referer", operation: "set", value: "https://askdisha.irctc.co.in/" }
        ]},
        condition: { urlFilter: "https://askdisha.irctc.co.in/*", resourceTypes: ["xmlhttprequest"] }
      }
    ]
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2) fetchTrainData listener
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchTrainData") {
    fetch("https://www.indianrail.gov.in/enquiry/FetchTrainData", {
      method: "GET",
      headers: {
        "Connection": "close",
        "sec-ch-ua-platform": "\"macOS\"",
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": getRandomUA(),
        "Accept": "*/*",
        "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
        "DNT": "1",
        "sec-ch-ua-mobile": "?0",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9"
      }
    })
    .then(res => { if (!res.ok) throw new Error(`Status ${res.status}`); return res.json(); })
    .then(data => {
      const processed = data.map(item => {
        const [number,name] = item.split(" - ").map(s=>s.trim());
        return { number, name };
      });
      sendResponse({ success:true, data:processed });
    })
    .catch(err => sendResponse({ success:false, error:err.toString() }));
    return true;
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 3) Promisified clear/wipe functions
// ─────────────────────────────────────────────────────────────────────────────
function clearAllTargetCookies() {
  const domains = ["askdisha.irctc.co.in","www.irctc.co.in","irctc.co.in","wps.irctc.co.in","irctcipay.com"];
  return Promise.all(domains.map(domain => new Promise(resolve => {
    chrome.cookies.getAll({ domain }, cookies => {
      if (!cookies.length) return resolve();
      Promise.all(cookies.map(c => {
        const proto = c.secure?"https://":"http://";
        const url = `${proto}${c.domain.replace(/^\./,"")}${c.path}`;
        return new Promise(done => chrome.cookies.remove({ url,name:c.name }, done));
      })).then(resolve);
    });
  })));
}

function clearSiteDataForTargets() {
  const origins = [
    "https://www.irctc.co.in","https://askdisha.irctc.co.in","https://irctc.co.in",
    "https://www.wps.irctc.co.in","https://wps.irctc.co.in","https://www.irctcipay.com","https://irctcipay.com"
  ];
  return new Promise(resolve => {
    chrome.browsingData.remove({ origins },{
      cookies:true,cache:true,localStorage:true,indexedDB:true,serviceWorkers:true
    }, resolve);
  });
}

function clearClientStorage(tabId) {
  return new Promise((resolve,reject) => {
    chrome.scripting.executeScript({
      target:{tabId},
      func:() => {
        localStorage.clear();
        sessionStorage.clear();
        indexedDB.databases().then(dbs => dbs.forEach(db => indexedDB.deleteDatabase(db.name)));
        caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
        if (navigator.serviceWorker) navigator.serviceWorker.getRegistrations()
          .then(regs => regs.forEach(r => r.unregister()));
      }
    }, () => chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve());
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// 4) Simulation sequence
// ─────────────────────────────────────────────────────────────────────────────

function startSimulationSequence() {
  Promise.all([clearAllTargetCookies(), clearSiteDataForTargets()])
    .then(() => {
      chrome.tabs.create({
        url:    "https://www.irctc.co.in/nget/train-search",
        active: true
      }, (tab) => {
        if (!tab || !tab.id) {
          console.error("❌ Failed to open simulation tab");
          isSimulating = false;
          return;
        }

        irctcTabId = tab.id;
        console.log(`🔄 Opened tab#${irctcTabId} with system UA`);

        // 1) Attach debugger
        setupDebuggerForTab(irctcTabId);

        // 2) Clear client-side storage
        clearClientStorage(irctcTabId)
          .then(() => {
            // 3) Inject and run your login automation
            return chrome.scripting.executeScript({
              target: { tabId: irctcTabId },
              func: automateLoginAndMonitor
            });
          })
          .then(() => {
            isSimulating = true;
            console.log("✅ Login automation injected");
          })
          .catch(err => {
            console.error("❌ Error during simulation setup:", err);
            isSimulating = false;
            cleanupDebugger(irctcTabId);
          });
      });
    })
    .catch(err => {
      console.error("❌ Simulation setup error:", err);
      isSimulating = false;
      if (irctcTabId) cleanupDebugger(irctcTabId);
    });
}




// ─────────────────────────────────────────────────────────────────────────────
// 4.1) Fresh Cookies Simulation
// ─────────────────────────────────────────────────────────────────────────────

function CookiesSimulationSequence() {
  const ua = getRandomUA();
  const { width, height } = getRandomDimensions();
  setRandomUA(ua);

  Promise.all([clearAllTargetCookies(), clearSiteDataForTargets()])
    .then(() => {
      chrome.windows.create({
        url: "https://www.irctc.co.in/nget/train-search",
        type: "popup",
        incognito: true,
        focused: true,
        width,
        height
      }, (win) => {
        irctcWinId = win.id;
        if (!win || !win.tabs || !win.tabs[0]) {
          console.error("Failed to open popup window");
          isSimulating = false;
          return;
        }
        const tab = win.tabs[0];
        irctcTabId = tab.id;
        console.log(`🔄 Opened popup#${win.id} tab#${tab.id} @${width}×${height} UA="${ua}"`);

        // 2) Resize the window's only tab
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (w, h) => window.resizeTo(w, h),
          args: [width, height]
        })
        .then(() => {
          // 3) Clear storage & kick off your automation
          clearClientStorage(tab.id)
            .then(() => chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: FreshLoginAndMonitor
            }))
            .then(() => isSimulating = true);
        })
        .catch(err => {
          console.error("Error setting viewport in popup:", err);
          isSimulating = false;
          cleanupDebugger(tab.id);
        });
      });
    })
    .catch(err => {
      console.error("❌ Simulation error:", err);
      isSimulating = false;
      if (irctcTabId) cleanupDebugger(irctcTabId);
    });
}




// ─────────────────────────────────────────────────────────────────────────────
// 5) Message listener wiring for simulation & cookie capture
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startIRCTCLoginSimulation") {
    if (irctcTabId !== null) {
      chrome.tabs.remove(irctcTabId, () => {
        irctcTabId = null;
        isSimulating = false;
        startSimulationSequence();
      });
    } else if (isSimulating) {
      sendResponse({ success: false, error: "Simulation in progress" });
      return true;
    } else {
      startSimulationSequence();
    }
    sendResponse({ success: true });
    return true;
  }

  if (message.action === "captureCookiesNow") {
    try {
      // 1) Extract window.grey
      chrome.scripting.executeScript({
        target: { tabId: irctcTabId },
        func: () => ({ grey: window.grey })
      }, results => {
        if (chrome.runtime.lastError) {
          console.error("Error extracting grey:", chrome.runtime.lastError);
        } else {
          const { grey } = results[0].result || {};
          chrome.storage.local.set({ grey }, () => {
            console.log("Stored grey:", grey);
          });
        }

        // 2) Tear down debugger and close tab
        if (irctcTabId) {
          cleanupDebugger(irctcTabId);
          chrome.tabs.remove(irctcTabId, () => {
            irctcTabId = null;
            isSimulating = false;
            // 3) Notify that cookies are ready (but not stored)
            chrome.runtime.sendMessage({ action: "cookiesReady" });
          });
        }
      });
    } catch (e) {
      console.error("Error in captureCookiesNow:", e);
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }
});



// ─────────────────────────────────────────────────────────────────────────────
// 5.1) Message Listener for Simulation Trigger & Cookie Grab
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startFreshCookiesSimulation") {
    if (irctcTabId !== null) {
      chrome.windows.remove(irctcWinId, () => {
        irctcWinId = irctcTabId = null;
        isSimulating = false;
        CookiesSimulationSequence();
      });
    } else if (isSimulating) {
      sendResponse({ success: false, error: "Simulation in progress" });
      return true;
    } else {
      CookiesSimulationSequence();
    }
    sendResponse({ success: true });
    return true;
  }

  if (message.action === "FreshCookiesNow") {
    // 1) grab cookies
    chrome.cookies.getAll({ domain: "irctc.co.in" }, cookies => {
      const cookieStr = cookies.map(c => `${c.name}=${c.value}`).join(";");
      chrome.storage.local.set({ irctcCookies: cookieStr }, () => {
        console.log("✔️ Stored IRCTC cookies:", cookieStr);

        // 2) cleanup debugger
        if (irctcTabId) cleanupDebugger(irctcTabId);

        // 3) close the popup window
        if (irctcWinId) {
          chrome.windows.remove(irctcWinId, () => {
            console.log(`🔒 Closed popup win#${irctcWinId}`);
            irctcWinId = irctcTabId = null;
            isSimulating = false;
          });
        }

        // 4) notify that cookies are ready
        chrome.runtime.sendMessage({ action: "FreshReady" });
      });
    });
    return true;
  }
});




// ─────────────────────────────────────────────────────────────────────────────
// 6) Utility listener for misc messages & factory reset
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "clearCookies") {
    chrome.cookies.getAll({ domain: "irctc.co.in" }, cookies => {
      cookies.forEach(c => {
        const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
        chrome.cookies.remove({ url, name: c.name });
      });
      sendResponse({ success: true });
    });
    return true;
  }

  if (msg.action === "showPopup") alert(msg.message);

  if (msg.action === "factoryReset") factoryResetExtension();
});



async function factoryResetExtension() {
  try {
    console.log("🔄 Starting factory reset…");
    await Promise.all([
      new Promise(r => chrome.storage.local.clear(r)),
      chrome.storage.sync ? new Promise(r => chrome.storage.sync.clear(r)) : Promise.resolve(),
      chrome.storage.session ? new Promise(r => chrome.storage.session.clear(r)) : Promise.resolve()
    ]);
    console.log("✅ chrome.storage.* cleared");

    chrome.tabs.query({}, tabs => {
      tabs.forEach(({ id }) => {
        chrome.scripting.executeScript({ target: { tabId: id }, func: () => localStorage.clear() }).catch(() => {});
      });
    });
    console.log("✅ window.localStorage cleared");

    let dbs = [];
    try { if (indexedDB.databases) dbs = await indexedDB.databases(); } catch (e) { console.warn(e); }
    dbs.filter(d => d.name).forEach(({ name }) => {
      const req = indexedDB.deleteDatabase(name);
      req.onsuccess = () => console.log(`✅ Deleted IndexedDB "${name}"`);
      req.onerror   = () => console.warn(`❌ Failed to delete IndexedDB "${name}"`);
    });
    if (caches && caches.keys) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
      console.log("✅ Caches deleted");
    }

    chrome.cookies.getAll({}, cookies => {
      cookies.forEach(c => {
        const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
        chrome.cookies.remove({ url, name: c.name });
      });
      console.log("✅ Cookies removed");
    });

    pendingRequests.clear();


    console.log("🔄 Reloading extension…");
    chrome.runtime.reload();
  } catch (err) {
    console.error("🛑 factoryReset error:", err);
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// 6.1) Retrieve stored credentials for autofill
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getStoredCredentials") {
    chrome.storage.local.get(['username','password'], items => {
      sendResponse({ username: items.username || '', password: items.password || '' });
    });
    return true;
  }
});


// ─────────────────────────────────────────────────────────────────────────────
// 6.2) Retrieve stored response data and tokens
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getStoredData") {
    try {
      chrome.storage.local.get(['captchaResponse', 'signInResponse', 'accessToken', 'greq', 'grey', 'irctcCookies'], items => {
        sendResponse({
          captchaResponse: items.captchaResponse || '',
          signInResponse: items.signInResponse || '',
          accessToken: items.accessToken || '',
          greq: items.greq || '',
          grey: items.grey || '',
          cookies: items.irctcCookies || ''
        });
      });
    } catch (e) {
      console.error("Error in getStoredData:", e);
      sendResponse({ error: e.message });
    }
    return true;
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 7) Incognito window tracking
// ─────────────────────────────────────────────────────────────────────────────
chrome.windows.onCreated.addListener(win => {
  if (win.incognito) incognitoWindowIds.add(win.id);
});
chrome.windows.onRemoved.addListener(windowId => {
  if (incognitoWindowIds.has(windowId)) {
    incognitoWindowIds.delete(windowId);
    if (incognitoWindowIds.size === 0) {
      chrome.storage.local.remove("irctcCookies");
    }
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 8) Login automation and error/Logout monitoring implementation
// ─────────────────────────────────────────────────────────────────────────────
function automateLoginAndMonitor() {
  const delay = ms => new Promise(res => setTimeout(res, ms));

  async function checkForLogout() {
    return Array.from(document.querySelectorAll('span'))
      .some(el => el.textContent.trim() === "Logout");
  }

  addInstruction("CLICK THE LOGIN BUTTON ON THE TOP");

  function autoFillForm() {
    return new Promise(resolve => {
      const userEl = document.querySelector('input[placeholder="User Name"],input[name*="username"]');
      const passEl = document.querySelector('input[placeholder="Password"],input[name*="password"]');
      const capEl = document.querySelector('input[placeholder="Enter Captcha"],input[name*="captcha"]');
      if (!userEl || !passEl || !capEl) {
        chrome.runtime.sendMessage({ action: "simulationFailed", error: "Login form not found" });
        return resolve(false);
      }
      chrome.runtime.sendMessage({ action: "getStoredCredentials" }, cred => {
        userEl.value = cred.username;
        passEl.value = cred.password;
        userEl.dispatchEvent(new Event("input",{bubbles:true}));
        passEl.dispatchEvent(new Event("input",{bubbles:true}));
        userEl.style.display = passEl.style.display = "none";
        capEl.style.display = "";
        resolve(true);
      });
    });
  }





function addInstruction(text, showArrow = false) {
    // Prevent multiple instruction boxes
    if (document.getElementById("instruction-box")) return;

    // Create the instruction box
    const box = document.createElement("div");
    box.id = "instruction-box";
    Object.assign(box.style, {
        position: "fixed",
        top: "30%", // Slightly lower for prominence
        left: "50%",
        transform: "translate(-50%, -50%)",
        background: "linear-gradient(45deg, #ff1a1a, #b30000)", // Intense red gradient
        color: "#fff200", // Bright yellow text for maximum contrast
        padding: "30px 50px", // Larger padding for bigger presence
        borderRadius: "15px",
        border: "4px solid #ff6666", // Thicker, lighter red border
        boxShadow: "0 0 30px rgba(255, 0, 0, 1), 0 0 50px rgba(255, 0, 0, 0.8)", // Aggressive glow
        zIndex: "1000000", // Ensure it's on top
        fontFamily: "'Impact', Arial, sans-serif", // Bold, aggressive font
        fontSize: "32px", // Larger text
        fontWeight: "900", // Extra bold
        textAlign: "center",
        textTransform: "uppercase", // All caps for urgency
        textShadow: "2px 2px 5px rgba(0, 0, 0, 0.7)", // Dark shadow for text pop
        animation: "shake 0.2s infinite, pulseGlow 0.8s infinite ease-in-out, flashBorder 1s infinite", // Multiple animations
        maxWidth: "90%", // Responsive but dominant
        lineHeight: "1.3", // Tight line height for intensity
        cursor: "pointer", // Suggests interactivity
    });
    box.textContent = text;

    // Add optional arrow
    if (showArrow) {
        const arrow = document.createElement("div");
        Object.assign(arrow.style, {
            position: "absolute",
            bottom: "-30px",
            left: "50%",
            transform: "translateX(-50%)",
            width: "0",
            height: "0",
            borderLeft: "20px solid transparent",
            borderRight: "20px solid transparent",
            borderTop: "30px solid #ff1a1a", // Match intense red
            filter: "drop-shadow(0 0 10px rgba(255, 0, 0, 1))", // Strong arrow glow
        });
        box.appendChild(arrow);
    }

    // Append to body
    document.body.appendChild(box);

    // Add CSS keyframes for animations (only once)
    if (!document.getElementById("instruction-box-styles")) {
        const styleSheet = document.createElement("style");
        styleSheet.id = "instruction-box-styles";
        styleSheet.textContent = `
            @keyframes pulseGlow {
                0% { box-shadow: 0 0 30px rgba(255, 0, 0, 1), 0 0 50px rgba(255, 0, 0, 0.8); }
                50% { box-shadow: 0 0 50px rgba(255, 0, 0, 1.5), 0 0 80px rgba(255, 0, 0, 1); }
                100% { box-shadow: 0 0 30px rgba(255, 0, 0, 1), 0 0 50px rgba(255, 0, 0, 0.8); }
            }
            @keyframes shake {
                0% { transform: translate(-50%, -50%) translateX(0); }
                25% { transform: translate(-50%, -50%) translateX(-5px); }
                50% { transform: translate(-50%, -50%) translateX(5px); }
                75% { transform: translate(-50%, -50%) translateX(-5px); }
                100% { transform: translate(-50%, -50%) translateX(0); }
            }
            @keyframes flashBorder {
                0% { border-color: #ff6666; }
                50% { border-color: #ffffff; }
                100% { border-color: #ff6666; }
            }
            @keyframes slamIn {
                0% { opacity: 0; transform: translate(-50%, -100%) scale(0.5); }
                80% { opacity: 1; transform: translate(-50%, -50%) scale(1.1); }
                100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
            }
        `;
        document.head.appendChild(styleSheet);
    }

    // Apply slam-in animation on load
    box.style.animation = "slamIn 0.4s ease-out, shake 0.2s infinite, pulseGlow 0.8s infinite ease-in-out, flashBorder 1s infinite";

    // Optional: Auto-remove after 5 seconds or on click for user control
    box.addEventListener("click", () => box.remove());
    // setTimeout(() => box.remove(), 5000); // Uncomment to auto-remove
}


  function updateInstruction(text) {
    const box = document.getElementById("instruction-box");
    if (box) box.textContent = text;
  }

  function removeInstruction() {
    const box = document.getElementById("instruction-box"); 
    if (box) box.remove();
  }

  async function monitor() {
    for (let i = 0; i < 60; i++) {
      if (document.querySelector('input[placeholder="User Name"]')) break;
      await delay(1000);
    }
    if (!await autoFillForm()) return;
    
    // Add captcha instruction
    updateInstruction("NOW FILL THE CAPTCHA AND CLICK SIGN IN");
    
    // Monitor captcha input
    const capEl = document.querySelector('input[placeholder="Enter Captcha"],input[name*="captcha"]');
    if (capEl) {
      const checkCaptchaFilled = async () => {
        if (capEl.value.length > 0) {
          updateInstruction("Signing in...");
          // Monitor for login button click or form submission
          const signInBtn = document.querySelector('button[type="submit"],button:contains("SIGN IN")');
          if (signInBtn) {
            signInBtn.addEventListener('click', () => startLoginMonitor());
          }
        }
      };
      
      capEl.addEventListener('input', checkCaptchaFilled);
      
      // Also check periodically in case event listener misses
      for (let i = 0; i < 120; i++) {
        if (capEl.value.length > 0) {
          updateInstruction("Signing in...");
          break;
        }
        await delay(1000);
      }
    }

    async function startLoginMonitor() {
      for (let i = 0; i < 120; i++) {
        if (await checkForLogout()) {
          removeInstruction();
          chrome.runtime.sendMessage({ action: "captureCookiesNow" });
          return;
        }
        await delay(1000);
      }
      removeInstruction();
      chrome.runtime.sendMessage({ action: "simulationFailed", error: "No response within timeout" });
    }

    // Start monitoring even if captcha isn't filled yet
    startLoginMonitor();
  }

  monitor();
}


// ─────────────────────────────────────────────────────────────────────────────
// 8.1) Login automation and error/Logout monitoring implementation
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
// 8.1) Search automation using your session tokens (replaces FreshLoginAndMonitor)
// ─────────────────────────────────────────────────────────────────────────────
async function FreshLoginAndMonitor() {
  const delay = ms => new Promise(res => setTimeout(res, ms));

  // 1) Pull in your popup-saved headers
  const session = await new Promise(resolve => {
    chrome.storage.local.get("irctcSession", ({ irctcSession }) => {
      resolve(irctcSession || {});
    });
  });

  if (!session.Authorization) {
    console.error("❌ IRCTC session not initialized—open the popup first.");
    return;
  }

  try {
    // 2) Pre-load the train-search page with those headers
    const resp = await fetch("https://www.irctc.co.in/nget/train-search", {
      method:      "GET",
      headers:     session,
      credentials: "include"
    });

    // 3) Rotate CSRF if provided
    const newCsrf = resp.headers.get("csrf-token");
    if (newCsrf) {
      session["Spa-Csrf-Token"] = newCsrf;
      chrome.storage.local.set({ irctcSession: session });
      window.csrfToken = newCsrf;
      console.log("🔄 CSRF token refreshed");
    }

    // 4) Wait for the “From” field to appear
    for (let i = 0; i < 30; i++) {
      if (document.querySelector('input[aria-autocomplete="list"][role="searchbox"].ng-tns-c57-8')) break;
      await delay(500);
    }

    // 5) Fill “NDLS” → select suggestion
    const fromInput = document.querySelector('input[aria-autocomplete="list"][role="searchbox"].ng-tns-c57-8');
    if (!fromInput) { console.error("❌ From input not found"); return; }
    fromInput.focus();
    fromInput.value = "NDLS";
    fromInput.dispatchEvent(new Event("input", { bubbles: true }));
    await delay(500);
    const fromOption = document.querySelector("#pr_id_1_list li");
    if (!fromOption) { console.error("❌ From option not found"); return; }
    fromOption.click();
    await delay(500);

    // 6) Fill “DBG” → select suggestion
    const toInput = document.querySelector('input[aria-autocomplete="list"][role="searchbox"].ng-tns-c57-9');
    if (!toInput) { console.error("❌ To input not found"); return; }
    toInput.focus();
    toInput.value = "DBG";
    toInput.dispatchEvent(new Event("input", { bubbles: true }));
    await delay(500);
    const toOption = document.querySelector("#pr_id_2_list li");
    if (!toOption) { console.error("❌ To option not found"); return; }
    toOption.click();
    await delay(500);

    // 7) Click “Find Trains”
    const searchBtn = document.querySelector('button.search_btn.train_Search[type="submit"]');
    if (!searchBtn) { console.error("❌ Search button not found"); return; }
    searchBtn.click();

    console.log("✅ Search submitted (NDLS → DBG)");
  } catch (err) {
    console.error("🚨 Search automation failed:", err);
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// 9) Open popup when extension icon clicked
// ─────────────────────────────────────────────────────────────────────────────
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});
