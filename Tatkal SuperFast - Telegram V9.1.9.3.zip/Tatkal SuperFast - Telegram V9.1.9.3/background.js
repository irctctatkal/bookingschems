chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab.url;
  if (!url) return;

  if (url.startsWith("https://www.irctc.co.in/nget/train-search")) {
    startSimulationSequence(tabId);
  }

  if (changeInfo.status === "complete" && /^https:\/\/(www\.)?irctc\.co\.in/.test(url)) {
    setupDebuggerForTab(tabId);
  }
});


let irctcTabId = null;
let isSimulating = false;
let currentDebugTab = null;
const pendingRequests = new Map();
let bmiyekCaptured = false;

initializeDebuggerListener();
function initializeDebuggerListener() {
  chrome.debugger.onEvent.addListener((debuggeeId, method, params) => {
    if (debuggeeId.tabId !== currentDebugTab) return;

    if (method === "Network.requestWillBeSent") {
      const { request } = params;
      const url = request.url;

      if (/recentTxnsDetails/.test(url) && request.headers) {
        const bmiyek = Object.entries(request.headers)
          .find(([name]) => name.toLowerCase() === "bmiyek")?.[1];
        if (bmiyek) {
          bmiyekCaptured = true;
          chrome.storage.local.set({ bmiyek });
        }
      }

      else if (!bmiyekCaptured && /allLapAvlFareEnq/.test(url) && request.headers) {
        const bmiyek = Object.entries(request.headers)
          .find(([name]) => name.toLowerCase() === "bmiyek")?.[1];
        if (bmiyek) {
          bmiyekCaptured = true;
          chrome.storage.local.set({ bmiyek });
        }
      }
    }

    else if (method === "Network.responseReceived") {
      const { requestId, response } = params;
      const url = response.url;

      if (
        /loginCaptcha/.test(url) ||
        /authprovider\/webtoken/.test(url) ||
        /allLapAvlFareEnq/.test(url)    ||
        /addonServices/.test(url)
      ) {
        pendingRequests.set(requestId, {
          url,
          headers: /allLapAvlFareEnq/.test(url) ? response.headers : undefined
        });
      }

      if (/bookingInitPayment/.test(url)) {
        const bodyText = response.body || "";
        if (/Unable/i.test(bodyText)) {
          chrome.runtime.sendMessage({
            action: "showPopup",
            message:
              "Your Account Has Payment Issues, Change IRCTC ID & Try Again"
          });
          return;
        }

        const csrfToken = Object.entries(response.headers || {})
          .find(([n]) => n.toLowerCase() === "csrf-token")?.[1];
        if (!csrfToken) {
          chrome.runtime.sendMessage({
            action: "showPopup",
            message:
              "Your Account Has Payment Issues, Change IRCTC ID & Try Again"
          });
          cleanupDebugger(debuggeeId.tabId);
          chrome.tabs.remove(debuggeeId.tabId, () => currentDebugTab = null);
          return;
        }
        chrome.storage.local.set({ csrfToken }, () => {
          chrome.storage.local.get(
            ["greq", "accessToken", "csrfToken"],
            (items) => {
              if (items.greq && items.accessToken && items.csrfToken) {
                chrome.runtime.sendMessage({ action: "cookiesReady" });
              }
              cleanupDebugger(debuggeeId.tabId);
              chrome.tabs.remove(debuggeeId.tabId, () => currentDebugTab = null);
            }
          );
        });
      }
    }


    else if (method === "Network.loadingFinished") {
      const { requestId } = params;
      const entry = pendingRequests.get(requestId);
      if (!entry) return;
      pendingRequests.delete(requestId);

      chrome.debugger.sendCommand(
        { tabId: debuggeeId.tabId },
        "Network.getResponseBody",
        { requestId },
        (result) => {
          if (chrome.runtime.lastError) {
            return;
          }
          let data;
          try { data = JSON.parse(result.body || ""); }
          catch { return; }

          const url     = entry.url;
          const headers = entry.headers || {};


          if (/loginCaptcha/.test(url)) {
            const greq = data.status || "";
            chrome.storage.local.set({ greq });
          }

          else if (/authprovider\/webtoken/.test(url)) {
            if (
              data.token_type?.toLowerCase() === "bearer" &&
              data.access_token
            ) {
              chrome.storage.local.set(
                { accessToken: data.access_token },
                () => {
                  chrome.storage.local.get(['greq'], ({ greq }) => {
                    if (!greq) {
                      chrome.runtime.sendMessage({
                        action: "showPopup",
                        message:
                          "Captcha Not Readable: Don't Click Login very Fast, Wait for website to load fully before clicking Login button"
                      });
                      cleanupDebugger(debuggeeId.tabId);
                      chrome.tabs.remove(debuggeeId.tabId, () => currentDebugTab = null);
                    }
                  });
                }
              );
            }
          }

          else if (/allLapAvlFareEnq/.test(url)) {
            chrome.storage.local.get("paymentMethod", ({ paymentMethod }) => {
              if (paymentMethod === "paytm") {
                const details = data.bankDetailDTO || [];
                const paytmUp = details.some(d => d.bankId === "78" || d.bankId === "117");
                if (paytmUp) {
                  chrome.storage.local.set({ bankId: "78" });
                } else {
                  // PayTM down → notify and tear down
                  chrome.runtime.sendMessage({
                    action: "showPopup",
                    message: "PayTM Gateway is Down, Use IRCTC UPI or Wallet"
                  });
                  cleanupDebugger(debuggeeId.tabId);
                  chrome.tabs.remove(debuggeeId.tabId, () => {
                    currentDebugTab = null;
                  });
                }
              }
            });
          }

          else if (/addonServices/.test(url)) {
            chrome.storage.local.get(["paymentMethod", "bankId"], ({ paymentMethod, bankId }) => {
              if (paymentMethod === "paytm" && !bankId) {
                const details = data.bankDetailDTO || [];
                const paytmUp = details.some(d => d.bankId === "78" || d.bankId === "117");
                if (paytmUp) {
                  chrome.storage.local.set({ bankId: "78" });
                } else {
                  // PayTM down → notify and tear down
                  chrome.runtime.sendMessage({
                    action: "showPopup",
                    message: "PayTM Gateway is Down, Use IRCTC UPI or Wallet"
                  });
                  cleanupDebugger(debuggeeId.tabId);
                  chrome.tabs.remove(debuggeeId.tabId, () => {
                    currentDebugTab = null;
                  });
                }
              }
            });
          }
        }
      );
    }

    // 4) Clean up on failure
    else if (method === "Network.loadingFailed") {
      pendingRequests.delete(params.requestId);
    }
  });
}


function setupDebuggerForTab(tabId) {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      return;
    }

    currentDebugTab = tabId;

    chrome.debugger.attach({ tabId }, "1.3", () => {
      if (chrome.runtime.lastError) {
        return;
      }

      chrome.debugger.sendCommand({ tabId }, "Network.enable", {}, () => {
        if (chrome.runtime.lastError) {
        }
      });
    });
  });
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "clearCookies") {
    chrome.cookies.getAll({ domain: "irctc.co.in" }, cookies => {
      cookies.forEach(c => {
        const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
        chrome.cookies.remove({ url, name: c.name });
      });
      sendResponse({ success: true });
    });
    return true;
  }

  if (msg.action === "showPopup") alert(msg.message);

  if (msg.action === "factoryReset") factoryResetExtension();
});
function cleanupDebugger(tabId) {
  try {
    chrome.debugger.detach({ tabId }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch (e) {}
}
function setRandomUA(ua) {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [10],
    addRules: [{
      id: 10,
      priority: 2,
      action: { type: "modifyHeaders", requestHeaders: [{ header: "User-Agent", operation: "set", value: ua }] },
      condition: { urlFilter: "<all_urls>", resourceTypes: ["main_frame","xmlhttprequest","sub_frame","other"] }
    }]
  });
}
// ─────────────────────────────────────────────────────────────────────────────
// Not Required now, Better Delete in production
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1,2,3,4,5,6,7],
    addRules: [

      {
        id: 1, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Referer", operation: "set", value: "https://www.wps.irctc.co.in/" }
        ]},
        condition: { urlFilter: "https://www.irctcipay.com/pgui/jsp/surchargelocale?request_localeA=&defaultLanguageA=", resourceTypes: ["main_frame","xmlhttprequest"] }
      },

      {
        id: 2, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Origin", operation: "set", value: "https://www.irctcipay.com" },
          { header: "Referer", operation: "set", value: "https://www.irctcipay.com/pgui/jsp/surchargePaymentPage.jsp" }
        ]},
        condition: { urlFilter: "https://www.irctcipay.com/*", resourceTypes: ["main_frame","xmlhttprequest"] }
      },

      {
        id: 3,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Accept",           operation: "set", value: "application/json, text/plain, */*" },
            { header: "Accept-Encoding",  operation: "set", value: "gzip, deflate, br" },
            { header: "Origin",           operation: "set", value: "https://www.irctc.co.in" },
            { header: "Referer",          operation: "set", value: "https://www.irctc.co.in/nget/train-search" },
            { header: "bmirak",           operation: "set", value: "webbm" },
            { header: "Dnt",              operation: "set", value: "1" },
            { header: "Priority",         operation: "set", value: 'u="1","i"' },
            { header: "Sec-Fetch-Site",   operation: "set", value: "same-origin" },
            { header: "Connection",       operation: "set", value: "keep-alive" },
            { header: "Sec-Fetch-Mode",   operation: "set", value: "cors" },
            { header: "Sec-Fetch-Dest",   operation: "set", value: "empty" },
            { header: "Sec-Ch-Ua-Mobile", operation: "set", value: "?1" },
            { header: "Sec-Ch-Ua-Platform", operation: "set", value: `"Android"` }
          ]
        }, 
        condition: {
          urlFilter: "|https://www.irctc.co.in/eticketing/*",
          resourceTypes: ["main_frame","xmlhttprequest","sub_frame","other"]
        }
      },

      {
        id: 4, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Origin", operation: "set", value: "https://secure.paytmpayments.com" },
          { header: "Referer", operation: "set", value: "https://secure.paytmpayments.com/" }
        ]},
        condition: { urlFilter: "https://secure.paytmpayments.com/theia/api/v1/processTransaction", resourceTypes: ["main_frame","xmlhttprequest"] }
      },

      {
        id: 5, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Accept", operation: "set", value: "application/json, text/plain, */*" },
          { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
          { header: "Origin", operation: "set", value: "https://www.irctc.co.in" },
          { header: "Referer", operation: "set", value: "https://www.irctc.co.in/nget/train-search" }
        ]},
        condition: { urlFilter: "https://www.wps.irctc.co.in/*", resourceTypes: ["main_frame","xmlhttprequest"] }
      },

      {
        id: 6, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Accept", operation: "set", value: "application/json, text/plain, */*" },
          { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
          { header: "Origin", operation: "set", value: "https://www.irctc.co.in" },
          { header: "Referer", operation: "set", value: "https://www.irctc.co.in/nget/train-search" },
          { header: "bmirak", operation: "set", value: "webbm" }
        ]},
        condition: { urlFilter: "|https://www.irctc.co.in/authprovider/webtoken*", resourceTypes: ["xmlhttprequest"] }
      },

      {
        id: 7, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          { header: "Origin", operation: "set", value: "https://askdisha.irctc.co.in" },
          { header: "Referer", operation: "set", value: "https://askdisha.irctc.co.in/" }
        ]},
        condition: { urlFilter: "https://askdisha.irctc.co.in/*", resourceTypes: ["xmlhttprequest"] }
      }
    ]
  });
});


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchTrainData") {
    fetch("https://www.indianrail.gov.in/enquiry/FetchTrainData", {
      method: "GET",
      headers: {
        "Connection": "close",
        "sec-ch-ua-platform": "\"macOS\"",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "*/*",
        "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
        "DNT": "1",
        "sec-ch-ua-mobile": "?0",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9"
      }
    })
    .then(res => { if (!res.ok) throw new Error(`Status ${res.status}`); return res.json(); })
    .then(data => {
      const processed = data.map(item => {
        const [number,name] = item.split(" - ").map(s=>s.trim());
        return { number, name };
      });
      sendResponse({ success:true, data:processed });
    })
    .catch(err => sendResponse({ success:false, error:err.toString() }));
    return true;
  }
});


function clearAllTargetCookies() {
  const domains = ["askdisha.irctc.co.in","www.irctc.co.in","irctc.co.in","wps.irctc.co.in","irctcipay.com"];
  return Promise.all(domains.map(domain => new Promise(resolve => {
    chrome.cookies.getAll({ domain }, cookies => {
      if (!cookies.length) return resolve();
      Promise.all(cookies.map(c => {
        const proto = c.secure?"https://":"http://";
        const url = `${proto}${c.domain.replace(/^\./,"")}${c.path}`;
        return new Promise(done => chrome.cookies.remove({ url,name:c.name }, done));
      })).then(resolve);
    });
  })));
}

function clearSiteDataForTargets() {
  const origins = [
    "https://www.irctc.co.in","https://askdisha.irctc.co.in","https://irctc.co.in",
    "https://www.wps.irctc.co.in","https://wps.irctc.co.in","https://www.irctcipay.com","https://irctcipay.com"
  ];
  return new Promise(resolve => {
    chrome.browsingData.remove({ origins },{
      cookies:true,cache:true,localStorage:true,indexedDB:true,serviceWorkers:true
    }, resolve);
  });
}

function clearClientStorage(tabId) {
  return new Promise((resolve,reject) => {
    chrome.scripting.executeScript({
      target:{tabId},
      func:() => {
        localStorage.clear();
        sessionStorage.clear();
        indexedDB.databases().then(dbs => dbs.forEach(db => indexedDB.deleteDatabase(db.name)));
        caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
        if (navigator.serviceWorker) navigator.serviceWorker.getRegistrations()
          .then(regs => regs.forEach(r => r.unregister()));
      }
    }, () => chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve());
  });
}

function startSimulationSequence(tabId) {
  chrome.scripting.executeScript({
    target: { tabId },
    func: automateLoginAndMonitor
  }, () => {
    if (chrome.runtime.lastError) {
      isSimulating = false;
    } else {
      isSimulating = true;
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startIRCTCLoginSimulation") {
    // helper to open the train-search page
    const openTrainSearchTab = () => {
      chrome.tabs.create(
        { url: "https://www.irctc.co.in/nget/train-search", active: true },
        (tab) => {
          irctcTabId   = tab.id;
          isSimulating = false;
        }
      );
    };

    if (irctcTabId !== null) {
      // close the old one, then open a fresh tab
      chrome.tabs.remove(irctcTabId, () => {
        irctcTabId   = null;
        isSimulating = false;
        openTrainSearchTab();
      });
    } else if (isSimulating) {
      // still mid-simulation, bail out
      sendResponse({ success: false, error: "Simulation in progress" });
      return true;
    } else {
      openTrainSearchTab();
    }

    sendResponse({ success: true });
    return true;
  }
});
async function factoryResetExtension() {
  try {
    await Promise.all([
      new Promise(r => chrome.storage.local.clear(r)),
      chrome.storage.sync ? new Promise(r => chrome.storage.sync.clear(r)) : Promise.resolve(),
      chrome.storage.session ? new Promise(r => chrome.storage.session.clear(r)) : Promise.resolve()
    ]);
    chrome.tabs.query({}, tabs => {
      tabs.forEach(({ id }) => {
        chrome.scripting.executeScript({ target: { tabId: id }, func: () => localStorage.clear() }).catch(() => {});
      });
    });
    let dbs = [];
    try { if (indexedDB.databases) dbs = await indexedDB.databases(); } catch (e) {}
    dbs.filter(d => d.name).forEach(({ name }) => {
      const req = indexedDB.deleteDatabase(name);
      req.onsuccess = () => {};
      req.onerror   = () => {};
    });
    if (caches && caches.keys) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
    chrome.cookies.getAll({}, cookies => {
      cookies.forEach(c => {
        const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
        chrome.cookies.remove({ url, name: c.name });
      });
    });
    pendingRequests.clear();
    chrome.runtime.reload();
  } catch (err) {}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getStoredCredentials") {
    chrome.storage.local.get(['username','password'], items => {
      sendResponse({ username: items.username || '', password: items.password || '' });
    });
    return true;
  }
});

function automateLoginAndMonitor() {
  const delay = ms => new Promise(res => setTimeout(res, ms));
  async function checkForLogout() {
    return Array.from(document.querySelectorAll('span'))
      .some(el => el.textContent.trim() === "Logout");
  }
  addInstruction("CLICK THE LOGIN BUTTON ON THE TOP");
  function autoFillForm() {
    return new Promise(resolve => {
      const userEl = document.querySelector('input[placeholder="User Name"],input[name*="username"]');
      const passEl = document.querySelector('input[placeholder="Password"],input[name*="password"]');
      const capEl = document.querySelector('input[placeholder="Enter Captcha"],input[name*="captcha"]');
      if (!userEl || !passEl || !capEl) {
        chrome.runtime.sendMessage({ action: "simulationFailed", error: "Login form not found" });
        return resolve(false);
      }
      chrome.runtime.sendMessage({ action: "getStoredCredentials" }, cred => {
        userEl.value = cred.username;
        passEl.value = cred.password;
        userEl.dispatchEvent(new Event("input",{bubbles:true}));
        passEl.dispatchEvent(new Event("input",{bubbles:true}));
        userEl.style.display = passEl.style.display = "none";
        capEl.style.display = "";
        resolve(true);
      });
    });
  }
function addInstruction(text, showArrow = false) {
    if (document.getElementById("instruction-box")) return;
    const box = document.createElement("div");
    box.id = "instruction-box";
    Object.assign(box.style, {
        position: "fixed",
        top: "30%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        background: "linear-gradient(45deg, #ff1a1a, #b30000)",
        color: "#fff200",
        padding: "30px 50px",
        borderRadius: "15px",
        border: "4px solid #ff6666",
        boxShadow: "0 0 30px rgba(255, 0, 0, 1), 0 0 50px rgba(255, 0, 0, 0.8)",
        zIndex: "1000000",
        fontFamily: "'Impact', Arial, sans-serif",
        fontSize: "32px",
        fontWeight: "900",
        textAlign: "center",
        textTransform: "uppercase",
        textShadow: "2px 2px 5px rgba(0, 0, 0, 0.7)",
        animation: "shake 0.2s infinite, pulseGlow 0.8s infinite ease-in-out, flashBorder 1s infinite",
        maxWidth: "90%",
        lineHeight: "1.3",
        cursor: "pointer",
    });
    box.textContent = text;
    if (showArrow) {
        const arrow = document.createElement("div");
        Object.assign(arrow.style, {
            position: "absolute",
            bottom: "-30px",
            left: "50%",
            transform: "translateX(-50%)",
            width: "0",
            height: "0",
            borderLeft: "20px solid transparent",
            borderRight: "20px solid transparent",
            borderTop: "30px solid #ff1a1a",
            filter: "drop-shadow(0 0 10px rgba(255, 0, 0, 1))",
        });
        box.appendChild(arrow);
    }
    document.body.appendChild(box);
    if (!document.getElementById("instruction-box-styles")) {
        const styleSheet = document.createElement("style");
        styleSheet.id = "instruction-box-styles";
        styleSheet.textContent = `
            @keyframes pulseGlow {
                0% { box-shadow: 0 0 30px rgba(255, 0, 0, 1), 0 0 50px rgba(255, 0, 0, 0.8); }
                50% { box-shadow: 0 0 50px rgba(255, 0, 0, 1.5), 0 0 80px rgba(255, 0, 0, 1); }
                100% { box-shadow: 0 0 30px rgba(255, 0, 0, 1), 0 0 50px rgba(255, 0, 0, 0.8); }
            }
            @keyframes shake {
                0% { transform: translate(-50%, -50%) translateX(0); }
                25% { transform: translate(-50%, -50%) translateX(-5px); }
                50% { transform: translate(-50%, -50%) translateX(5px); }
                75% { transform: translate(-50%, -50%) translateX(-5px); }
                100% { transform: translate(-50%, -50%) translateX(0); }
            }
            @keyframes flashBorder {
                0% { border-color: #ff6666; }
                50% { border-color: #ffffff; }
                100% { border-color: #ff6666; }
            }
            @keyframes slamIn {
                0% { opacity: 0; transform: translate(-50%, -100%) scale(0.5); }
                80% { opacity: 1; transform: translate(-50%, -50%) scale(1.1); }
                100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
            }
        `;
        document.head.appendChild(styleSheet);
    }
    box.style.animation = "slamIn 0.4s ease-out, shake 0.2s infinite, pulseGlow 0.8s infinite ease-in-out, flashBorder 1s infinite";
    box.addEventListener("click", () => box.remove());
}

  function updateInstruction(text) {
    const box = document.getElementById("instruction-box");
    if (box) box.textContent = text;
  }
  function removeInstruction() {
    const box = document.getElementById("instruction-box"); 
    if (box) box.remove();
  }
  async function monitor() {
    for (let i = 0; i < 60; i++) {
      if (document.querySelector('input[placeholder="User Name"]')) break;
      await delay(1000);
    }
    if (!await autoFillForm()) return;
    updateInstruction("NOW FILL THE CAPTCHA AND CLICK SIGN IN");
    const capEl = document.querySelector('input[placeholder="Enter Captcha"],input[name*="captcha"]');
    if (capEl) {
      const checkCaptchaFilled = async () => {
        if (capEl.value.length > 0) {
          updateInstruction("Signing in...");
          const signInBtn = document.querySelector('button[type="submit"],button:contains("SIGN IN")');
          if (signInBtn) {
            signInBtn.addEventListener('click', () => startLoginMonitor());
          }
        }
      };
      capEl.addEventListener('input', checkCaptchaFilled);
      for (let i = 0; i < 120; i++) {
        if (capEl.value.length > 0) {
          updateInstruction("Signing in...");
          break;
        }
        await delay(1000);
      }
    }
    async function startLoginMonitor() {
      for (let i = 0; i < 120; i++) {
        if (await checkForLogout()) {
          removeInstruction();
          return;
        }
        await delay(1000);
      }
      removeInstruction();
      chrome.runtime.sendMessage({ action: "simulationFailed", error: "No response within timeout" });
    }
    startLoginMonitor();
  }
  monitor();
}

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});